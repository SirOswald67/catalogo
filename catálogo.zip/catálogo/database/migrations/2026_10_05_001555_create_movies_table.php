<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasTable('movies')) {
            $hasGenre = Schema::hasColumn('movies', 'genre');
            $hasReleaseYear = Schema::hasColumn('movies', 'release_year');

            Schema::table('movies', function (Blueprint $table) use ($hasGenre, $hasReleaseYear): void {
                if (! $hasGenre) {
                    $table->string('genre')->nullable();
                }

                if (! $hasReleaseYear) {
                    $table->integer('release_year')->nullable();
                }
            });

            if (Schema::hasColumn('movies', 'year')) {
                DB::table('movies')
                    ->whereNull('release_year')
                    ->update(['release_year' => DB::raw('`year`')]);
            }

            return;
        }

        Schema::create('movies', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('genre');
            $table->integer('release_year');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        $hasLegacyColumns = Schema::hasColumn('movies', 'synopsis')
            || Schema::hasColumn('movies', 'year')
            || Schema::hasColumn('movies', 'cover');

        if ($hasLegacyColumns) {
            $columnsToRemove = array_values(array_filter(
                ['genre', 'release_year'],
                fn (string $column): bool => Schema::hasColumn('movies', $column)
            ));

            if ($columnsToRemove !== []) {
                Schema::table('movies', function (Blueprint $table) use ($columnsToRemove): void {
                    $table->dropColumn($columnsToRemove);
                });
            }

            return;
        }

        Schema::dropIfExists('movies');
    }
};
