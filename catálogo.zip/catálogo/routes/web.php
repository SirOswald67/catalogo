<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

use App\Http\Controllers\MovieController;

// 1. GET para obtener todos los registros de películas
Route::get('/movies', [MovieController::class, 'index']);

// 2. GET para obtener un registro específico filtrado por ID
Route::get('/movies/{id}', [MovieController::class, 'show']);

// 3. POST para la inserción de un nuevo registro
Route::post('/movies', [MovieController::class, 'store']);