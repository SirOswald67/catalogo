<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Movie; // Asegúrate de tener tu modelo creado

class MovieController extends Controller
{
    /**
     * GET: Obtener todos los registros de la base de datos
     */
    public function index()
    {
        $movies = Movie::all();
        
        return response()->json([
            'success' => true,
            'data' => $movies
        ], 200);
    }

    /**
     * GET: Obtener los datos de un registro específico por su ID
     */
    public function show($id)
    {
        // Busca la película o devuelve un error 404 automáticamente si no existe
        $movie = Movie::findOrFail($id);

        return response()->json([
            'success' => true,
            'data' => $movie
        ], 200);
    }

    /**
     * POST: Insertar un nuevo registro en la base de datos
     */
    public function store(Request $request)
    {
        // Validación de todos los datos obligatorios exigidos por la base de datos
        $validatedData = $request->validate([
            'title'        => 'required|string|max:255',
            'synopsis'     => 'required|string',
            'year'         => 'required|integer',
            'cover'        => 'required|string|max:255',
            'genre'        => 'nullable|string|max:100',
            'release_year' => 'required|integer',
        ]);

        // Creación del nuevo registro en la base de datos usando Eloquent
        $movie = Movie::create($validatedData);

        return response()->json([
            'success' => true,
            'message' => 'Película registrada exitosamente',
            'data'    => $movie
        ], 201);
    }
}   